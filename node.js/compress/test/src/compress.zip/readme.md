# Node.js에서 파일 압축하기
