/*jshint -W097 */
/*jslint node: true */
'use strict';

import AdmZip from 'adm-zip';

// reading archives
const zip = new AdmZip("E:/greenfrog/study/node.js/compress/test/src/compress.7z");
const zipEntries = zip.getEntries(); // an array of ZipEntry records

zipEntries.forEach(function(zipEntry) {
    console.log(zipEntry.toString()); // outputs zip entries information
    if (zipEntry.entryName == "readme.md") {
         console.log(zipEntry.data.toString('utf8'));
    }
});
// // outputs the content of some_folder/my_file.txt
// console.log(zip.readAsText("some_folder/my_file.txt"));
// // extracts the specified file to the specified location
// zip.extractEntryTo(/*entry name*/"some_folder/my_file.txt", /*target path*/"/home/me/tempfolder", /*maintainEntryPath*/false, /*overwrite*/true);
// // extracts everything
// zip.extractAllTo(/*target path*/"/home/me/zipcontent/", /*overwrite*/true);
